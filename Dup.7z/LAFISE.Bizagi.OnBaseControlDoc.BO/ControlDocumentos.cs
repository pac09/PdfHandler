﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Xml;
using Lafise.AperturaCuenta.Utilidad;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.Base;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.ClasesProxy;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxReportesBizagi;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.Interfaces;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.AperturaCasos;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.TratamientoDocumentos;

namespace LAFISE.Bizagi.SWOnBaseControlDoc.BO
{
    /// <summary>
    /// Clase Principal de capa BO para Windows Service
    /// </summary>
    public class ControlDocumentos : ITratamientoDocumentos, IAperturaCasosBizagi
    {
        //Classes
        protected BaseTratamientoDocumentos baseTratamiento;
        protected BaseAperturaCasosBizagi baseAperturaCasosBizagi;

        protected readonly string sPais;
        //protected DAO.ControlDocs controlExpedientes;
        protected int vencimientoParaProductos;
        protected int pGraciaProdCredito;
        protected int pGraciaProdTarjetas;

        /// <summary>
        /// Constructor que inicializa clases abstractas que implementan interfaces
        /// </summary>
        public ControlDocumentos(BaseTratamientoDocumentos baseTratamiento, BaseAperturaCasosBizagi baseAperturaCasosBizagi)
        {
            this.baseTratamiento = baseTratamiento;
            this.baseAperturaCasosBizagi = baseAperturaCasosBizagi;
        }

        /// <summary>
        /// Constructor para inicializar
        /// </summary>
        public ControlDocumentos()
        {
            sPais = "NI";
        }

        /// <summary>
        /// Metodo principal, procesa los documentos y crea casos en Bizagi
        /// </summary>
        /// <returns>TResult como System.String</returns>
        public async Task<string> ProcesarDocumentos() 
        {
            string sResultado = string.Empty;
            
            try
            {
                //Log inicio de Windows Service
                Loggerdb.LogInfo("Inicio Servicio Windows Control Documentos OnBase " + DateTime.Now, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Consulta, sPais);

                //Obteniendo clientes de la Plataforma OnBase
                List<eClientesOnBase> clientesOnBase = ConsultarClientesOnBase();
                //Obtenemos los clientes Coporativos, serán usados para validar sí un clientes es Corp, validar sus Ejecutivos
                List<eClientesCorpOnBase> clientesCorporativosDwh = ConsultarClientesCorporativos();

                //
                //Batch a Insertar
                List<eControlDocument> bulkInsertion = new List<eControlDocument>();

                //Truncamos la data de la Tabla de Control que contiene el Consolidado de Documentos
                TruncarTablaConsolidado();
                
                vencimientoParaProductos = ConsultaPeriodoVencimiento();
                pGraciaProdCredito = ConsultaPeriodoProdCredito();
                pGraciaProdTarjetas = ConsultaPeriodoProdTarjeta();
                
                //Para cada cliente en ONBASE
                foreach (var item in clientesOnBase)
                {
                    //Consumiendo el Web Method ObtenerProductoCliente de ACJ
                    ClasesProxy.ConsultasGenerales oConGeneral = new ClasesProxy.ConsultasGenerales();

                    OProductoCliente oProducto = oConGeneral.ConsultaProductoCliente(item.NroCliente, "");
                    bool productoExistente = false;
                    
                    //Asigna TRUE si al menos un producto esta ACTIVO
                    foreach (var itemProd in oProducto.Productos)
                    {
                        //Validacion para PRESTAMOS
                        foreach (var itemPrestamo in itemProd.Prestamos.Where(itemPrestamo => itemPrestamo.Estado == "A"))
                        {
                            productoExistente = true;
                        }

                        //Validacion para CERTIFICADOS
                        foreach (var itemCertificado in itemProd.Certificados.Where(itemCertificado => itemCertificado.Estado == "A"))
                        {
                            productoExistente = true;
                        }

                        //Validacion para CUENTAS
                        foreach (var itemCuenta in itemProd.Cuentas.Where(itemCuenta => itemCuenta.Estado == "A"))
                        {
                            productoExistente = true;
                        }

                        //Validacion para TARJETAS
                        foreach (var itemTarjeta in itemProd.TarjetasDeCredito.Where(itemTarjeta => itemTarjeta.Estado == "A"))
                        {
                            productoExistente = true;
                        }
                    }

                    //Se valida si el Cliente en cuestion tiene al menos un Producto ACTIVO
                    if (productoExistente)
                    {
                        //Valores Booleanos para validar ejecución de Metodos de Documentos Faltantes o Documentos Pendientes
                        bool activarDocumentosPendientes = Convert.ToBoolean(ConfigurationManager.AppSettings["enableFaltantesxCliente"]);
                        bool activarDocumentosVencidos = Convert.ToBoolean(ConfigurationManager.AppSettings["activarVencidosxCliente"]);

                        List<eControlDocument> docsConsolidado = new List<eControlDocument>();

                        //Sí estan activados ambos metodos
                        if (activarDocumentosPendientes && activarDocumentosVencidos)
                        {
                            var taskDocPendientes = ObtenerDocPendientesAsync(item.NroCliente);
                            var taskDocVencidos = ObtenerDocVencidossAsync(item.NroCliente, vencimientoParaProductos);

                            //Correr tareas en Paralelo
                            await Task.WhenAll(taskDocPendientes, taskDocVencidos);

                            //Obtener los IList<eControlDocument>
                            var docPendientes = taskDocPendientes.Result;
                            var docVencidos = taskDocVencidos.Result;

                            //Consolidar Documentos Pendientes y Vencidos
                            docsConsolidado = docPendientes.Concat(docVencidos).ToList();
                        }
                        else
                        {
                            //Sí esta activado unicamente la generación para Documentos Vencidos
                            if (activarDocumentosPendientes == false && activarDocumentosVencidos)
                            {
                                var taskDocVencidos = ObtenerDocVencidossAsync(item.NroCliente, vencimientoParaProductos);

                                //Correr tareas en Paralelo
                                await Task.WhenAll(taskDocVencidos);

                                //Obtener los IList<eControlDocument>
                                var docVencidos = taskDocVencidos.Result;

                                //Consolidar Documentos Pendientes y Vencidos
                                docsConsolidado = docVencidos.ToList();
                            }
                            else if (activarDocumentosPendientes && activarDocumentosVencidos == false)
                            {
                                //Sí esta activado unicamente la generación para Documentos Faltantes
                                var taskDocPendientes = ObtenerDocPendientesAsync(item.NroCliente);

                                //Correr tareas en Paralelo
                                await Task.WhenAll(taskDocPendientes);

                                //Obtener los IList<eControlDocument>
                                var docPendientes = taskDocPendientes.Result;

                                //Consolidar Documentos Pendientes y Vencidos
                                docsConsolidado = docPendientes.ToList();
                            }
                            else
                            {
                                throw new Exception("Ambos KEY en el archivo de configuracion estan en 0, no se traen documentos vencidos y/o pendientes");
                            }
                        }
                        
                        //Realizamos Append a la lista a insertar, cuando tenga más de 20K de registros
                        bulkInsertion.AddRange(docsConsolidado);
                        if (bulkInsertion.Count() >= 20000)
                        {
                            //Insertamos data en forma Masiva
                            InsertarDatosConsolidado(bulkInsertion);
                            //Limpia lista para volver a llenarla
                            bulkInsertion.Clear();
                        }
                    }
                }

                //En caso que terminamos de recorrer clientes y quedo un Batch residual menos a 20K de registros, insertar
                if (bulkInsertion.Any())
                {
                    InsertarDatosConsolidado(bulkInsertion);
                    //Liberamos esta lista para no tener mas memoria disponible, en este todos los documentos han sido insertados
                    bulkInsertion.Clear();
                }

                //APERTURA DE CASOS, posterios a la insercion de consolidados, traer por el Numero de clientes (iteraciones a realizar)
                int numeroClientesConsolidado = ObtenerNumeroClientesConsolidado();

                for (int i = 0; i < numeroClientesConsolidado; i++)
                {
                    //Se usa el contexto dentro del ciclo for para interactuar con BD
                    using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
                    {
                        //Obteniendo ultimo cliente
                        long ultimoCliente =
                            (long)oConsultar.Set<BizConsolidadoControlDoc>()
                                .OrderBy(row => new { row.FlagProcesado, row.NumeroDeCliente })
                                .Where(row => row.FlagProcesado == false)
                                .Select(row => row.NumeroDeCliente).FirstOrDefault();

                        //Toma documentos pendientes y vencidos para el Ultimo cliente
                        var documentosUltimoCliente = oConsultar.Set<BizConsolidadoControlDoc>().Where(row => row.FlagProcesado == false && row.NumeroDeCliente == ultimoCliente);

                        //Lista de documentos agrupados por Cliente
                        var consolidadoPorCliente = documentosUltimoCliente.Where(row => row.ClaseDeDocumento.Contains("Cliente")
                                                        && string.IsNullOrEmpty(row.TipoDeProducto) && row.NumeroDeProducto == null).ToList();

                        //Aperturando caso por Cliente
                        eEstructuraOut informacionCasoGenerado;
                        //Contiene {idCase, NoCaso}
                        string[] infoCasoBizagi;
                        if (consolidadoPorCliente.Any())
                        {
                            eEstructuraInXml xmlCasoPorCliente = ToEEstructuraInXml(consolidadoPorCliente);

                            //Validar sino existe en tabla de control
                            if (!ValidacionCasoExistente(ultimoCliente))
                            {
                                informacionCasoGenerado = GenerarCaso(xmlCasoPorCliente);
                                //Validar si el caso fue generado
                                if (informacionCasoGenerado.CodigoError == 0)
                                {
                                    infoCasoBizagi = InformacionCasoBizagi(informacionCasoGenerado.xmlResultado);

                                    //Ingresar caso generado en tabla de control
                                    var nuevoCasoBizagi = new eControlDocOnBase
                                    {
                                        NoCaso = infoCasoBizagi[1],
                                        IdCase = Convert.ToInt32(infoCasoBizagi[0]),
                                        NoCliente = ultimoCliente,
                                        NoProducto = null,
                                        FechaApertura = DateTime.Now,
                                        FechaCierre = null,
                                        Completado = false
                                    };
                                    InsertarDatos(nuevoCasoBizagi);
                                }
                                else
                                {
                                    //Enviar LOG a Base de datos LOGGER explicando porque no se puede generar caso
                                    Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Cliente: " + ultimoCliente + ". Mensaje: " + informacionCasoGenerado.MensajeError, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                                }
                            }
                            else
                            {
                                //Enviar LOG a Base de datos LOGGER el caso ya existe
                                Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Caso Existente para Cliente: " + ultimoCliente + ". Producto: NULL", "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                            }
                        }

                        //Lista de Productos
                        var listaDeProductos = documentosUltimoCliente.Where(row => row.ClaseDeDocumento.Contains("Producto")).Select(row => row.NumeroDeProducto).Distinct().ToList();
                        if (listaDeProductos.Any())
                        {
                            //Verificar en la lista de Clientes Corporativos el cliente en Cuestion
                            bool flagClientCorp = clientesCorporativosDwh.Any(a => a.NroCliente == ultimoCliente);

                            //Validar que se tenga el mismo ejecutivo de Credito en los productos -- O DEBE SER EL EJECUTIVO DE NEGOCIOS????
                            eResultadoValidaEje oValidacion = ValidaHomogeneidadEjecutivos(listaDeProductos);

                            //Sí el Cliente es Corporativo
                            if (flagClientCorp)
                            {
                                //Sí el hay Homogeneidad de  ejecutivos de Credito O NEGOCIO?? aperturar caso
                                if (oValidacion.ResultadoValidacion == true)
                                {
                                    //Aperturando caso por Productos ... para cada producto aperturar un caso
                                    foreach (var oItemProducto in listaDeProductos)
                                    {
                                        var consolidadoPorProducto = documentosUltimoCliente.Where(row => row.ClaseDeDocumento.Contains("Producto") && row.NumeroDeProducto == oItemProducto).ToList();
                                        eEstructuraInXml xmlCasoPorProducto = ToEEstructuraInXml(consolidadoPorProducto, pGraciaProdCredito, pGraciaProdTarjetas);
                                        //La clase para generar casos solo puede ser null en caso de Creditos o TC
                                        if (xmlCasoPorProducto != null)
                                        {
                                            //Validar sino existe en tabla de control
                                            if (!ValidacionCasoExistente(ultimoCliente, oItemProducto.ToString()))
                                            {
                                                informacionCasoGenerado = GenerarCaso(xmlCasoPorProducto);
                                                //Validar si el caso fue generado
                                                if (informacionCasoGenerado.CodigoError == 0)
                                                {
                                                    infoCasoBizagi = InformacionCasoBizagi(informacionCasoGenerado.xmlResultado);

                                                    //Ingresar caso generado en tabla de control
                                                    var nuevoCasoBizagi = new eControlDocOnBase()
                                                    {
                                                        NoCaso = infoCasoBizagi[1],
                                                        IdCase = Convert.ToInt32(infoCasoBizagi[0]),
                                                        NoCliente = ultimoCliente,
                                                        NoProducto = oItemProducto.ToString(),
                                                        FechaApertura = DateTime.Now,
                                                        FechaCierre = null,
                                                        Completado = false
                                                    };
                                                    InsertarDatos(nuevoCasoBizagi);
                                                }
                                                else
                                                {
                                                    //Enviar LOG a Base de datos LOGGER explicando porque no se puede generar caso
                                                    Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Cliente: " + ultimoCliente + ". Producto: " + oItemProducto + ". Mensaje: " + informacionCasoGenerado.MensajeError, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                                                }
                                            }
                                            else
                                            {
                                                //Enviar LOG a Base de datos LOGGER el caso ya existe
                                                Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Caso Existente para Cliente: " + ultimoCliente + ". Producto: " + oItemProducto, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                                            }
                                        }
                                    }

                                }
                                else
                                {
                                    string errorMessage =
                                        "Este mensaje será algo redactado por CyP, el error es porque el ejecutivo de Credito sea diferente en los productos";

                                    Utilidad.SendEmail("ONBASE WinService-Error Homogeneidad de Ejecutivo de Credito",
                                        "Bizagi@lafise.com", string.Empty, string.Empty, string.Empty, errorMessage);
                                }
                            }
                            else
                            {
                                //Aperturando caso por Productos ... para cada producto aperturar un caso
                                foreach (var oItemProducto in listaDeProductos)
                                {
                                    var consolidadoPorProducto = documentosUltimoCliente.Where(row => row.ClaseDeDocumento.Contains("Producto") && row.NumeroDeProducto == oItemProducto).ToList();
                                    eEstructuraInXml xmlCasoPorProducto = ToEEstructuraInXml(consolidadoPorProducto, pGraciaProdCredito, pGraciaProdTarjetas);
                                    //La clase para generar casos solo puede ser null en caso de Creditos o TC
                                    if (xmlCasoPorProducto != null)
                                    {
                                        //Validar sino existe en tabla de control
                                        if (!ValidacionCasoExistente(ultimoCliente, oItemProducto.ToString()))
                                        {
                                            informacionCasoGenerado = GenerarCaso(xmlCasoPorProducto);
                                            //Validar si el caso fue generado
                                            if (informacionCasoGenerado.CodigoError == 0)
                                            {
                                                infoCasoBizagi = InformacionCasoBizagi(informacionCasoGenerado.xmlResultado);

                                                //Ingresar caso generado en tabla de control
                                                var nuevoCasoBizagi = new eControlDocOnBase()
                                                {
                                                    NoCaso = infoCasoBizagi[1],
                                                    IdCase = Convert.ToInt32(infoCasoBizagi[0]),
                                                    NoCliente = ultimoCliente,
                                                    NoProducto = oItemProducto.ToString(),
                                                    FechaApertura = DateTime.Now,
                                                    FechaCierre = null,
                                                    Completado = false
                                                };
                                                InsertarDatos(nuevoCasoBizagi);
                                            }
                                            else
                                            {
                                                //Enviar LOG a Base de datos LOGGER explicando porque no se puede generar caso
                                                Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Cliente: " + ultimoCliente + ". Producto: " + oItemProducto + ". Mensaje: " + informacionCasoGenerado.MensajeError, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                                            }
                                        }
                                        else
                                        {
                                            //Enviar LOG a Base de datos LOGGER el caso ya existe
                                            Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. Caso Existente para Cliente: " + ultimoCliente + ". Producto: " + oItemProducto, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
                                        }
                                    }
                                }

                            }
                        }

                        //Update en tabla BizConsolidadoControlDoc (Consolidado de Documentos Pendientes y Vencidos)
                        ActualizarConsolidadoDocs(ultimoCliente);
                    }
                }
                
                //Log inicio de Windows Service
                Loggerdb.LogInfo("Fin Servicio Windows Control Documentos OnBase " + DateTime.Now, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Consulta, sPais);
            }
            catch (Exception ex)
            {
                sResultado = ex.Message;
                Loggerdb.LogInfo("ERROR Servicio Windows Control Documentos OnBase. ERROR:" + ex.Message, "0", eTipoServicio.SERVICIO_CONTROLDOC_ONBASE, eTipoTransaccion.Ninguna, sPais);
            }
            return sResultado;
        }
        
        #region Implementacion_BaseTratamiento

        public List<eClientesOnBase> ConsultarClientesOnBase()
        {
            return baseTratamiento.ConsultarClientesOnBase();
        }
        
        public List<eClientesCorpOnBase> ConsultarClientesCorporativos()
        {
            return baseTratamiento.ConsultarClientesCorporativos();
        }

        public int ConsultaPeriodoProdCredito()
        {
            return baseTratamiento.ConsultaPeriodoProdCredito();
        }

        public int ConsultaPeriodoProdTarjeta()
        {
            return baseTratamiento.ConsultaPeriodoProdTarjeta();
        }

        public int ConsultaPeriodoVencimiento()
        {
            return baseTratamiento.ConsultaPeriodoVencimiento();
        }

        public Task<IList<eControlDocument>> ObtenerDocPendientesAsync(long clientId)
        {
            return baseTratamiento.ObtenerDocPendientesAsync(clientId);
        }

        public Task<IList<eControlDocument>> ObtenerDocVencidossAsync(long clientId, int vencimientoProductos)
        {
            return baseTratamiento.ObtenerDocVencidossAsync(clientId, vencimientoProductos);
        }

        public IList<eControlDocument> ObtenerDocPendientes(long clientId)
        {
            return baseTratamiento.ObtenerDocPendientes(clientId);
        }

        public IList<eControlDocument> ObtenerDocVencidos(long clientId, int vencimientoProductos)
        {
            return baseTratamiento.ObtenerDocVencidos(clientId, vencimientoProductos);
        }

        public IList<eControlDocument> BasicObtenerDocVencidos(long clientId, int vencimientoProductos)
        {
            return baseTratamiento.BasicObtenerDocVencidos(clientId, vencimientoProductos);
        }

        public void InsertarDatosConsolidado(IList<eControlDocument> listaPorInsertar)
        {
            baseTratamiento.InsertarDatosConsolidado(listaPorInsertar);
        }

        public void TruncarTablaConsolidado()
        {
            baseTratamiento.TruncarTablaConsolidado();
        }

        #endregion

        #region Implementacion_BaseAperturaCasosBizagi

        public int ObtenerNumeroClientesConsolidado()
        {
            return baseAperturaCasosBizagi.ObtenerNumeroClientesConsolidado();
        }

        public resultadoDatosProducto ConsultarDatosProductoTcPos(decimal noProducto)
        {
            return baseAperturaCasosBizagi.ConsultarDatosProductoTcPos(noProducto);
        }

        public bool ClasificaProducto(string paramTipoProducto)
        {
            return baseAperturaCasosBizagi.ClasificaProducto(paramTipoProducto);
        }

        public bool AperturarCaso(resultadoDatosProducto paramDatosProducto, int valueDiasCredito = 0, int valueDiasTarjeta = 0)
        {
            return baseAperturaCasosBizagi.AperturarCaso(paramDatosProducto, valueDiasCredito, valueDiasTarjeta);
        }
        
        public eEstructuraInXml ToEEstructuraInXml(List<BizConsolidadoControlDoc> values, int valueDiasCredito = 0, int valueDiasTarjeta = 0)
        {
            return baseAperturaCasosBizagi.ToEEstructuraInXml(values, valueDiasCredito = 0, valueDiasTarjeta = 0);
        }

        public bool ValidacionCasoExistente(decimal noCliente, string noProducto = null)
        {
            return baseAperturaCasosBizagi.ValidacionCasoExistente(noCliente, noProducto);
        }

        public eEstructuraOut GenerarCaso(eEstructuraInXml parametros)
        {
            return baseAperturaCasosBizagi.GenerarCaso(parametros);
        }

        public int? GetBizAgiClasificacionTipoProducto(string paramTipoProducto)
        {
            return baseAperturaCasosBizagi.GetBizAgiClasificacionTipoProducto(paramTipoProducto);
        }

        public int GetBizAgiCentroCostoEk(string paramCentroCostos)
        {
            return baseAperturaCasosBizagi.GetBizAgiCentroCostoEk(paramCentroCostos);
        }

        public string[] InformacionCasoBizagi(XmlNode bizagiResponse)
        {
            return baseAperturaCasosBizagi.InformacionCasoBizagi(bizagiResponse);
        }

        public eResultadoValidaEje ValidaHomogeneidadEjecutivos(List<long?> lstProductosCorpClient)
        {
            return baseAperturaCasosBizagi.ValidaHomogeneidadEjecutivos(lstProductosCorpClient);
        }
        
        public void InsertarDatos(eControlDocOnBase data)
        {
            baseAperturaCasosBizagi.InsertarDatos(data);
        }

        public void ActualizarConsolidadoDocs(long clientePorActualizar)
        {
            baseAperturaCasosBizagi.ActualizarConsolidadoDocs(clientePorActualizar);
        }

        #endregion
    }
}

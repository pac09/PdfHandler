﻿using System;
using System.Collections.Generic;
using System.Xml;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxReportesBizagi;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.AperturaCasos;

namespace LAFISE.Bizagi.SWOnBaseControlDoc.BO.Interfaces
{
    /// <summary>
    /// Interface para Apertura de Casos de Bizagi por el Windows Service de OnBase
    /// </summary>
    public interface IAperturaCasosBizagi
    {
        /// <summary>
        /// Obtener numero de clientes en la tabla de Documentos Consolidado
        /// </summary>
        /// <returns></returns>
        int ObtenerNumeroClientesConsolidado();

        /// <summary>
        /// Llamado al SP SpBiz0002InitDateCcxTc, busca Datos de Producto TC y POS en SISCO
        /// </summary>
        /// <param name="noProducto"></param>
        /// <returns></returns>
        resultadoDatosProducto ConsultarDatosProductoTcPos(decimal noProducto);

        /// <summary>
        /// Metodo para validar la clasificacion de un producto como Credito o Tarjetas de Credito
        /// </summary>
        /// <param name="paramTipoProducto"></param>
        /// <returns></returns>
        bool ClasificaProducto(string paramTipoProducto);

        /// <summary>
        /// Metodo para validar Apertura de casos en Productos de Credito o Tarjetas de Credito
        /// </summary>
        /// <param name="paramDatosProducto"></param>
        /// <returns></returns>
        bool AperturarCaso(resultadoDatosProducto paramDatosProducto, int valueDiasCredito = 0, int valueDiasTarjeta = 0);

        /// <summary>
        /// Metodo de parseo, ConsolidadoControlDoc (Consolidados por Cliente) a eEstructuraInXml (Data para XML, aperturar casos)
        /// </summary>
        /// <returns></returns>
        eEstructuraInXml ToEEstructuraInXml(List<BizConsolidadoControlDoc> values, int valueDiasCredito = 0, int valueDiasTarjeta = 0);

        /// <summary>
        /// Metodo para validar si existe el caso en tabla de control [dbo].[BIZCONTROLDOCONBASE]
        /// </summary>
        /// <param name="noCliente"></param>
        /// <param name="noProducto"></param>
        /// <returns></returns>
        bool ValidacionCasoExistente(decimal noCliente, string noProducto = null);

        /// <summary>
        /// Metodo de generación de Casos
        /// </summary>
        /// <param name="parametros"></param>
        /// <exception cref="Exception"></exception>
        eEstructuraOut GenerarCaso(eEstructuraInXml parametros);

        /// <summary>
        /// Ejecuta Stored procedure para traer de la parametrica [dbo].[GEV_pTipoProductos] los ID para Tipo De Producto según [dbo].[EDD_pTipoprod]
        /// </summary>
        /// <param name="paramTipoProducto"></param>
        /// <returns></returns>
        int? GetBizAgiClasificacionTipoProducto(string paramTipoProducto);

        /// <summary>
        /// Funcion de EF para traer centro de Costos e insertarlo en relleno de XML
        /// </summary>
        /// <param name="paramCentroCostos"></param>
        /// <returns></returns>
        int GetBizAgiCentroCostoEk(string paramCentroCostos);

        /// <summary>
        /// Metodo para retornar idCase y NoCaso de Bizagi
        /// </summary>
        /// <param name="bizagiResponse"></param>
        /// <returns></returns>
        string[] InformacionCasoBizagi(XmlNode bizagiResponse);

        /// <summary>
        /// Metodo para evaluar si tenemos los mismos ejecutivos de negocio, para Productos de Credito Corporativo
        /// </summary>
        /// <param name="lstProductosCorpClient"></param>
        /// <returns></returns>
        eResultadoValidaEje ValidaHomogeneidadEjecutivos(List<long?> lstProductosCorpClient);

        /// <summary>
        /// Metodo para insertar data en la tabla de control que contiene todos los documentos Pendientes y Vencidos de casos Aperturados
        /// </summary>
        /// <param name="data"></param>
        void InsertarDatos(eControlDocOnBase data);

        /// <summary>
        /// Metodo para actualizar documentos procesados (se busca por numero de cliente pero actualiza aquellos cuyos casos fueron creados por Cliente y Producto)
        /// </summary>
        /// <param name="clientePorActualizar"></param>
        void ActualizarConsolidadoDocs(long clientePorActualizar);

    }
}

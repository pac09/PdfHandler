﻿using System.Collections.Generic;
using System.Threading.Tasks;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.TratamientoDocumentos;

namespace LAFISE.Bizagi.SWOnBaseControlDoc.BO.Interfaces
{
    /// <summary>
    /// Interface para Tratamiento de Documentos en Windows Service de OnBase
    /// </summary>
    public interface ITratamientoDocumentos
    {
        /// <summary>
        /// Obtener la Vista OBNIC_Clientes provee todos los Clientes que poseen productos cargados en OnBase
        /// </summary>
        /// <returns></returns>
        List<eClientesOnBase> ConsultarClientesOnBase();
        
        /// <summary>
        /// Consumir SP que trae de DWH todos los Clientes Corporativos
        /// </summary>
        /// <returns></returns>
        List<eClientesCorpOnBase> ConsultarClientesCorporativos();

        /// <summary>
        /// Metodo para traer valor de Dias Documentos Pendientes para Creditos para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        int ConsultaPeriodoProdCredito();

        /// <summary>
        /// Metodo para traer valor de Dias Documentos Pendientes para Tarjetas para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        int ConsultaPeriodoProdTarjeta();

        /// <summary>
        /// Metodo para traer valor de vencimiento para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        int ConsultaPeriodoVencimiento();

        /// <summary>
        /// Ejecuta de manera Asincrona la tarea que corre el metodo que ejecuta un Parallel LINQ
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        Task<IList<eControlDocument>> ObtenerDocPendientesAsync(long clientId);

        /// <summary>
        /// Ejecuta de manera Asincrona la tarea que corre el metodo que ejecuta un Parallel LINQ
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        Task<IList<eControlDocument>> ObtenerDocVencidossAsync(long clientId, int vencimientoProductos);

        /// <summary>
        /// Ejecuta de manera Asincrona el SP OBNIC_Doc_FaltantesxCliente que permite consultar los documentos Pendientes por cliente
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        IList<eControlDocument> ObtenerDocPendientes(long clientId);

        /// <summary>
        /// Ejecuta de manera Asincrona el SP OBNIC_Doc_VencidosxCliente que permite consultar los documentos Vencidos por cliente
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="vencimientoProductos"></param>
        /// <returns></returns>
        IList<eControlDocument> ObtenerDocVencidos(long clientId, int vencimientoProductos);


        /// <summary>
        /// Metodo para traer los Documentos Vencidos por Cliente, se separo la logica para poder ejecutarlo
        /// dos veces, en caso de contar con Documentos a los 3 meses, se ejecuta con 4 meses
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="vencimientoProductos"></param>
        /// <returns></returns>
        IList<eControlDocument> BasicObtenerDocVencidos(long clientId, int vencimientoProductos);

        /// <summary>
        /// Metodo para insertar data en la tabla de control que contiene todos los documentos Pendientes y Vencidos
        /// </summary>
        /// <param name="listaPorInsertar"></param>
        void InsertarDatosConsolidado(IList<eControlDocument> listaPorInsertar);

        /// <summary>
        /// Metodo para truncar la tabla de control que contiene todos los documentos Pendientes y Vencidos
        /// </summary>
        void TruncarTablaConsolidado();
    }
}

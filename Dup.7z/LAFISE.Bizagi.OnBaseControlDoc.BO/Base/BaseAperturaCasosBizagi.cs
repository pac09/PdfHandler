﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml;
using System.Xml.Linq;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.ClasesProxy;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxReportesBizagi;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxSisco;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.Interfaces;
using LAFISE.Bizagi.SWOnBaseControlDoc.DAO;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.AperturaCasos;

namespace LAFISE.Bizagi.SWOnBaseControlDoc.BO.Base
{
    /// <summary>
    /// Clase Abstracta para Apertura Casos de Bizagi con el Windows Service de OnBase
    /// </summary>
    public class BaseAperturaCasosBizagi : IAperturaCasosBizagi
    {
        protected DAO.ControlDocs controlExpedientes;
        
        /// <summary>
        /// Obtener numero de clientes en la tabla de Documentos Consolidado
        /// </summary>
        /// <returns></returns>
        public int ObtenerNumeroClientesConsolidado()
        {
            int noClientes;

            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                noClientes = oConsultar.SpBiz003ObtenerClientesConsolidado().FirstOrDefault() ?? 0;
            }
            return noClientes;
        }

        /// <summary>
        /// Llamado al SP SpBiz0002InitDateCcxTc, busca Datos de Producto TC y POS en SISCO
        /// </summary>
        /// <param name="noProducto"></param>
        /// <returns></returns>
        public resultadoDatosProducto ConsultarDatosProductoTcPos(decimal noProducto)
        {
            resultadoDatosProducto oResultadoDatosProd = null;

            using (SISCOEntities oConsultar = new SISCOEntities())
            {
                //Obteniendo data del modelo EF
                foreach (var item in oConsultar.SpBiz0002InitDateCcxTc(noProducto.ToString(CultureInfo.InvariantCulture)))
                {
                    oResultadoDatosProd = new resultadoDatosProducto(
                         item.FECHADESOLICITUD.Value,     //Viene siendo para la clase FechaDesembolso
                         Convert.ToInt64(item.CENTRODECOSTO),
                         item.TIPOPRODUCTO,
                         "",
                         "",
                         0,
                         ""
                    );
                }
            }
            return oResultadoDatosProd;
        }

        /// <summary>
        /// Metodo para validar la clasificacion de un producto como Credito o Tarjetas de Credito
        /// </summary>
        /// <param name="paramTipoProducto"></param>
        /// <returns></returns>
        public bool ClasificaProducto(string paramTipoProducto)
        {
            bool flagProductoCreditoTarjeta;

            //Consulta en ReportesBizagi si el producto pertener a Creditos o Tarjetas
            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                flagProductoCreditoTarjeta = Convert.ToBoolean(oConsultar.SpBiz004ClasificaProductos(paramTipoProducto).FirstOrDefault() ?? 0);
            }
            return flagProductoCreditoTarjeta;
        }

        /// <summary>
        /// Metodo para validar Apertura de casos en Productos de Credito o Tarjetas de Credito
        /// </summary>
        /// <param name="paramDatosProducto"></param>
        /// <param name="valueDiasCredito"></param>
        /// <param name="valueDiasTarjeta"></param>
        /// <returns></returns> 
        public bool AperturarCaso(resultadoDatosProducto paramDatosProducto, int valueDiasCredito = 0, int valueDiasTarjeta = 0)
        {
            bool flagApertura = false;
            DateTime fechaInicial = paramDatosProducto.FechaDesembolso;

            long dias = Math.Abs(Convert.ToInt64((fechaInicial - DateTime.Now).TotalDays));


            if (dias > valueDiasCredito || dias > valueDiasTarjeta)
            {
                flagApertura = true;
            }
            
            return flagApertura;
        }

        /// <summary>
        /// Metodo de parseo, ConsolidadoControlDoc (Consolidados por Cliente) a eEstructuraInXml (Data para XML, aperturar casos)
        /// </summary>
        /// <returns></returns>
        public eEstructuraInXml ToEEstructuraInXml(List<BizConsolidadoControlDoc> values, int valueDiasCredito = 0, int valueDiasTarjeta = 0)
        {
            controlExpedientes = new ControlDocs();

            //Traemos datos de Cliente, el NoCliente no cambia así que tomar el primero
            resultadoDatosCliente oResultadoDatosCliente = controlExpedientes.ConsultarDatosCliente(values.Select(element => element.NumeroDeCliente).FirstOrDefault());

            //Traemos datos del Producto, FECHADESEMBOLSO y CENTRODECOSTO, en dependencia del Producto
            decimal noProducto = values.Select(element => element.NumeroDeProducto).FirstOrDefault() ?? 0;

            resultadoDatosProducto oResultadoDatosProducto = (noProducto != 0 ? controlExpedientes.ConsultarDatosProducto(noProducto) : null) ??
                                      (noProducto != 0 ? ConsultarDatosProductoTcPos(noProducto) : null);

            //Consulta la parametrica para traer Tipo Producto
            int? tipoDeProducto = null;
            string tipoDeProductoParametro = values.Select(x => x.TipoDeProducto).FirstOrDefault();
            if (!string.IsNullOrEmpty(tipoDeProductoParametro))
                tipoDeProducto = GetBizAgiClasificacionTipoProducto(tipoDeProductoParametro);

            //Armar clase para relleno de XML
            eEstructuraInXml convertedValues = new eEstructuraInXml()
            {
                Usuario = "admon",
                Dominio = "domain",
                AsignacionManual = false,           //Debe settearse en FALSE por indicaciones en apertura automatica de casos - C&P

                c_DocumentosCaso = values.Select(val => new eEstructuraDocumentosXml()
                {
                    FechaVencimiento = val.FechaDeVencimiento,
                    TipoDocumento = val.TipoDeDocumento,
                    TipoIncidencia = val.Clasificacion,
                    EjecutivoNegocio = oResultadoDatosProducto == null ? "" : oResultadoDatosProducto.EjecutivoNegocio
                }).ToList(),
                
                Comentario = "CASO GENERADO POR USUARIO ONBASE",
                ConfirmarInfo = false,
                CreadorCaso = 1L,                //Cambiar este valor por otro
                FechaCreacion = DateTime.Now,

                m_Cliente = new List<eEstructuraClienteXml> { (new eEstructuraClienteXml() {
                    CentroCostos = oResultadoDatosProducto == null ? GetBizAgiCentroCostoEk((oResultadoDatosCliente.CentroDeCosto).ToString()) : GetBizAgiCentroCostoEk((oResultadoDatosProducto.CentroDeCosto).ToString()),
                    Correo = oResultadoDatosCliente.CorreoElectronico,
                    Ddc = oResultadoDatosCliente.Ddc,
                    EjecutivoCredito = (oResultadoDatosProducto != null && noProducto != 0) ? oResultadoDatosProducto.EjecutivoCredito : oResultadoDatosCliente.EjecutivoCredito,
                    Telefono = oResultadoDatosCliente.NumeroTelefono,
                    NoClienteProducto = values.Select(value => value.NumeroDeCliente.ToString(CultureInfo.InvariantCulture)).FirstOrDefault(),
                    NombreCliente = oResultadoDatosCliente.NombreCliente,
                    NoProducto = values.Select(value => value.NumeroDeProducto).FirstOrDefault(),
                    TipoProducto = tipoDeProducto
                })},

                Manual = false,
                NoBusqueda = false
            };

            //Metodo de criterio para Productos de Credito, Tarjetas de Credito esta en CERO dias
            if ((oResultadoDatosProducto != null) && ClasificaProducto(oResultadoDatosProducto.TipoProducto))
            {
                if (!AperturarCaso(oResultadoDatosProducto, valueDiasCredito, valueDiasTarjeta))
                {
                    convertedValues = null;
                }
            }

            return convertedValues;
        }

        /// <summary>
        /// Metodo para validar si existe el caso en tabla de control [dbo].[BIZCONTROLDOCONBASE]
        /// </summary>
        /// <param name="noCliente"></param>
        /// <param name="noProducto"></param>
        /// <returns></returns>
        public bool ValidacionCasoExistente(decimal noCliente, string noProducto = null)
        {
            bool flagCasoExistente = false;

            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                List<BIZCONTROLDOCONBASE> result;
                if (string.IsNullOrEmpty(noProducto))
                {
                    //Obteniendo data del modelo EF
                    result = (from data in oConsultar.BIZCONTROLDOCONBASEs
                              where data.COMPLETADO == false && data.NOCLIENTE == noCliente
                              select data).ToList();
                }
                else
                {
                    result = (from data in oConsultar.BIZCONTROLDOCONBASEs
                              where (data.COMPLETADO == false && data.NOCLIENTE == noCliente) && (data.NOPRODUCTO == noProducto)
                              select data).ToList();
                }
                //Si existe el caso bandera true
                if (result.Any())
                {
                    flagCasoExistente = true;
                }

            }

            return flagCasoExistente;
        }

        /// <summary>
        /// Metodo de generación de Casos
        /// </summary>
        /// <param name="parametros"></param>
        /// <exception cref="Exception"></exception>
        public eEstructuraOut GenerarCaso(eEstructuraInXml parametros)
        {
            //Apertura de Casos en Bizagi, este XmlNode es necesario para leer respuesta
            XmlNode xmlOut;
            eEstructuraOut eSalida = null;

            try
            {
                //eEstructuraOut eSalida = null;
                XDocument xResultadoControlDoc;
                eSalida = new eEstructuraOut();
                var wf = new WorkflowEngineSOA();

                //Creando xpath
                //Leyendo el recurso embebido
                Stream sArchivo = Assembly.GetExecutingAssembly().GetManifestResourceStream("LAFISE.Bizagi.SWOnBaseControlDoc.BO.FormatoXML.xCrearCaso.xml");
                StreamReader reader = new StreamReader(sArchivo);
                xResultadoControlDoc = XDocument.Load(reader);
                reader.Close();

                //Configurando los elementos cabecera
                xResultadoControlDoc.Element("BizAgiWSParam").Element("domain").SetValue(parametros.Dominio);
                xResultadoControlDoc.Element("BizAgiWSParam").Element("userName").SetValue(parametros.Usuario);

                //Setteando valores
                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("AsignacionManual").SetValue(parametros.AsignacionManual);

                //c_DocumentosCaso
                foreach (var item in parametros.c_DocumentosCaso)
                {
                    XElement nodo = new XElement("GEV_cDocumentos", new XElement("fechaVencimiento", item.FechaVencimiento), new XElement("tipoDocumento", item.TipoDocumento), new XElement("tipoIncidencia", item.TipoIncidencia));
                    xResultadoControlDoc.Element("BizAgiWSParam")
                      .Element("Cases")
                      .Element("Case")
                      .Element("Entities")
                      .Element("GEV_ExcepcionesVencimien")
                      .Element("c_DocumentosCaso").Add(nodo);
                }

                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("comentario").SetValue(parametros.Comentario);
                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("confirmarInfo").SetValue(parametros.ConfirmarInfo);
                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("creadorCaso").SetValue(parametros.CreadorCaso);
                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("FechaCreacion").SetValue(parametros.FechaCreacion);

                //m_Cliente
                foreach (var item in parametros.m_Cliente)
                {
                    xResultadoControlDoc.Element("BizAgiWSParam")
                       .Element("Cases")
                       .Element("Case")
                       .Element("Entities")
                       .Element("GEV_ExcepcionesVencimien")
                       .Element("m_Cliente").Add();
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("centroCostos")
                        .SetValue(item.CentroCostos);
                    //.SetValue(100);
                    xResultadoControlDoc
                        .Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("correo")
                        .SetValue(item.Correo);
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("telefono")
                        .SetValue(item.Telefono);
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("noClienteProducto")
                        .SetValue(item.NoClienteProducto);
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases").Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("nombreCliente")
                        .SetValue(item.NombreCliente);
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("noProducto").SetValue((object)item.NoProducto ?? 0);
                    xResultadoControlDoc.Element("BizAgiWSParam")
                        .Element("Cases")
                        .Element("Case")
                        .Element("Entities")
                        .Element("GEV_ExcepcionesVencimien")
                        .Element("m_Cliente")
                        .Element("tipoProducto").SetValue((object)item.TipoProducto ?? 0);
                }

                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("manual").SetValue(parametros.Manual);
                xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_ExcepcionesVencimien").Element("noBusqueda").SetValue(parametros.NoBusqueda);
                //xResultadoControlDoc.Element("BizAgiWSParam").Element("Cases").Element("Case").Element("Entities").Element("GEV_GestionExcepcionesVencimien").Element("noCaso").SetValue(parametros.NoCaso);

                //Preparando el xml
                XmlDocument xdoc = new XmlDocument();
                xdoc.LoadXml(xResultadoControlDoc.ToString());

                xmlOut = wf.createCases(xdoc);
                //wf.createCases(xdoc);

                eSalida.xmlResultado = xmlOut;
                eSalida.CodigoError = 0;
                eSalida.MensajeError = string.Empty;
            }
            catch (Exception ex)
            {
                if (eSalida == null) eSalida = new eEstructuraOut();

                eSalida.CodigoError = -1;
                eSalida.MensajeError = ex.Message;
            }
            return eSalida;
        }

        /// <summary>
        /// Ejecuta Stored procedure para traer de la parametrica [dbo].[GEV_pTipoProductos] los ID para Tipo De Producto según [dbo].[EDD_pTipoprod]
        /// </summary>
        /// <param name="paramTipoProducto"></param>
        /// <returns></returns>
        public int? GetBizAgiClasificacionTipoProducto(string paramTipoProducto)
        {
            int? tipoProduct;
            using (var oConsultar = new ReportesBizagiEntities())
            {
                tipoProduct = oConsultar.SpBiz005ClasificaTipoDeProducto(paramTipoProducto).FirstOrDefault();
            }
            return tipoProduct;
        }

        /// <summary>
        /// Funcion de EF para traer centro de Costos e insertarlo en relleno de XML
        /// </summary>
        /// <param name="paramCentroCostos"></param>
        /// <returns></returns>
        public int GetBizAgiCentroCostoEk(string paramCentroCostos)
        {
            var oConsultar = new ReportesBizagiEntities();
            //int centroCostosResponse = oConsultar.FnBiz0001GetCentroCostosEk(paramCentroCostos).FirstOrDefault() ?? 0;
            int centroCostosResponse = oConsultar.Database.SqlQuery<int>(string.Format("SELECT [dbo].[FnBiz0001GetCentroCostosEk]({0})", paramCentroCostos)).FirstOrDefault();
            return centroCostosResponse;
        }

        /// <summary>
        /// Metodo para retornar idCase y NoCaso de Bizagi
        /// </summary>
        /// <param name="bizagiResponse"></param>
        /// <returns></returns>
        public string[] InformacionCasoBizagi(XmlNode bizagiResponse)
        {
            // {idCase, NoCaso}
            string[] infoCaso = { bizagiResponse.SelectNodes("process/processId")[0].InnerText, 
                                   bizagiResponse.SelectNodes("process/processRadNumber")[0].InnerText };
            return infoCaso;
        }

        /// <summary>
        /// Metodo para evaluar si tenemos los mismos ejecutivos de negocio, para Productos de Credito Corporativo
        /// </summary>
        /// <param name="lstProductosCorpClient"></param>
        /// <returns></returns>
        public eResultadoValidaEje ValidaHomogeneidadEjecutivos(List<long?> lstProductosCorpClient)
        {
            controlExpedientes = new ControlDocs();

            //Concatena lista List<long?> en una cadena string
            string parameterString = lstProductosCorpClient.Select(i => i.ToString()).Aggregate((s1, s2) => "'" + s1 + "'" + ", " + "'" + s2 + "'");

            //Traemos data de la capa DAO
            eResultadoValidaEje oResultado = controlExpedientes.ValidaHomogeneidadEjecutivos(parameterString);
            
            if (oResultado.CodigoError == 0)
            {
                //Comparar que todos los ejecutivos sean el mismo
                string[] arrayEjecutivosCred = oResultado.EjecutivosCorps.Select(corp => corp.EjecutivoDeCredito).ToArray();
                
                //Recorremos arreglo de ejecutivos para comprar cada elemento con el elemento que le sucede
                for (int i = 0; i < arrayEjecutivosCred.Length; i++)
                {
                    //Esto para Validar 
                    if ((i + 1) < arrayEjecutivosCred.Length)
                    {
                        if (!arrayEjecutivosCred[i].Equals(arrayEjecutivosCred[i + 1]))
                        {
                            //Se settea en falso, o sea Validacion Negativa, hay diferentes Ejecutivos de Credito
                            oResultado.ResultadoValidacion = false;

                            oResultado.CodigoError = 3;
                            oResultado.MensajeError = "ERROR #3: Ejecutivo de Negocio diferente, producto " + oResultado.EjecutivosCorps.Where(corp => corp.EjecutivoDeNegocio.Equals(arrayEjecutivosCred[i])).Select(corp => corp.NoCreditoCorporativo) +
                                                            " difiere de Ejecutivo de producto " + oResultado.EjecutivosCorps.Where(corp => corp.EjecutivoDeNegocio.Equals(arrayEjecutivosCred[i + 1])).Select(corp => corp.NoCreditoCorporativo);
                        }
                    }
                }
            }
           
            return oResultado;
        }

        /// <summary>
        /// Metodo para insertar data en la tabla de control que contiene todos los documentos Pendientes y Vencidos de casos Aperturados
        /// </summary>
        /// <param name="data"></param>
        public void InsertarDatos(eControlDocOnBase data)
        {
            ReportesBizagiEntities oConsultar = new ReportesBizagiEntities();

            var dataPorInsertar = new BIZCONTROLDOCONBASE
            {
                NOCASO = data.NoCaso,
                IDCASE = data.IdCase,
                NOCLIENTE = data.NoCliente,
                NOPRODUCTO = data.NoProducto,
                FECHAAPERTURA = data.FechaApertura,
                FECHACIERRE = data.FechaCierre,
                COMPLETADO = data.Completado
            };
            oConsultar.BIZCONTROLDOCONBASEs.Add(dataPorInsertar);
            oConsultar.SaveChanges();
        }

        /// <summary>
        /// Metodo para actualizar documentos procesados (se busca por numero de cliente pero actualiza aquellos cuyos casos fueron creados por Cliente y Producto)
        /// </summary>
        /// <param name="clientePorActualizar"></param>
        public void ActualizarConsolidadoDocs(long clientePorActualizar)
        {
            using (var db = new ReportesBizagiEntities())
            {
                var docsClientePorActualizar = db.Set<BizConsolidadoControlDoc>().Where(row => row.FlagProcesado == false && row.NumeroDeCliente == clientePorActualizar).ToList(); ;
                docsClientePorActualizar.ForEach(a => a.FlagProcesado = true);
                db.SaveChanges();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core;
using System.Linq;
using System.Threading.Tasks;
using System.Transactions;
using EntityFramework.BulkInsert.Extensions;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxOnBase;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.CtxReportesBizagi;
using LAFISE.Bizagi.SWOnBaseControlDoc.BO.Interfaces;
using LAFISE.Bizagi.SWOnBaseControlDoc.Entidad.TratamientoDocumentos;

namespace LAFISE.Bizagi.SWOnBaseControlDoc.BO.Base
{
    /// <summary>
    /// Clase Abstracta para Tratamiento de Documentos en Windows Service de OnBase
    /// </summary>
    public class BaseTratamientoDocumentos : ITratamientoDocumentos
    {
        /// <summary>
        /// Obtener la Vista OBNIC_Clientes provee todos los Clientes que poseen productos cargados en OnBase
        /// La modificacion consiste en insertar el cumulo de clientes de OnBase en ReportesBizagi (tabla: [dbo].[BizOnBaseClientes])
        /// </summary>
        /// <returns></returns>
        public List<eClientesOnBase> ConsultarClientesOnBase()
        {
            List<eClientesOnBase> oResultadoClientes;
            List<eRespuestaImportacionClientes> respuestaImportacion = new List<eRespuestaImportacionClientes>();

            try
            {
                using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
                {
                    respuestaImportacion.AddRange(oConsultar.SpBiz021ActualizaDccClientesOnBase().Select(
                        itemRespuestaImportacionClientes => new eRespuestaImportacionClientes(
                            itemRespuestaImportacionClientes.ErrorNumber, 
                            itemRespuestaImportacionClientes.ErrorSeverity, 
                            itemRespuestaImportacionClientes.ErrorState, 
                            itemRespuestaImportacionClientes.ErrorProcedure, 
                            itemRespuestaImportacionClientes.ErrorLine, 
                            itemRespuestaImportacionClientes.ErrorMessage
                        )));
                
                    //Validar Respuesta de Importacion de Clientes de OnBase
                    int errornumber= respuestaImportacion.Select(a => a.ErrorNumber).FirstOrDefault() ?? 0;

                    if (errornumber == 0)
                    {
                        throw new Exception("Codigo de Error: " + errornumber + " Mensaje de Error: " +
                            respuestaImportacion.Select(a => a.ErrorMessage).FirstOrDefault());
                    }

                    //Numero Top para los clientes a seleccionar una vez hecho el proceso de importacion
                    int topForClients = Convert.ToInt32(ConfigurationManager.AppSettings["valueTopForClients"]);

                    //Tomamos el Numero de Clientes segun el key del App.config
                    oResultadoClientes = (from a in oConsultar.BizOnBaseClientes
                                          orderby a.Prioridad descending 
                                          select new eClientesOnBase(
                                              a.NroCliente,
                                              a.NombreCliente,
                                              a.IdBizOnBaseClientes
                                              )).Take(topForClients).ToList();
                }
            }
            catch (EntityException ex)
            {
                throw ex;
            }
            return oResultadoClientes;
        }

        /// <summary>
        /// Metodo para ejecutar el SP SpBiz022ObtenerClientCorpOnBase, el cual trae los clientes corporativos del banco DWH
        /// </summary>
        /// <returns></returns>
        public List<eClientesCorpOnBase> ConsultarClientesCorporativos()
        {
            List<eClientesCorpOnBase> oResultado;
            List<eRespuestaImportacionClientesCorp> respuestaImportacionCC = new List<eRespuestaImportacionClientesCorp>();

            try
            {
                using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
                {
                    respuestaImportacionCC.AddRange(oConsultar.SpBiz022ObtenerClientCorpOnBase().Select(
                        itemRespuestaImportacionClientes => new eRespuestaImportacionClientesCorp(
                            itemRespuestaImportacionClientes.ErrorNumber,
                            itemRespuestaImportacionClientes.ErrorSeverity,
                            itemRespuestaImportacionClientes.ErrorState,
                            itemRespuestaImportacionClientes.ErrorProcedure,
                            itemRespuestaImportacionClientes.ErrorLine,
                            itemRespuestaImportacionClientes.ErrorMessage
                        )));

                    //Validar Respuesta de Importacion de Clientes de OnBase
                    int errornumber = respuestaImportacionCC.Select(a => a.ErrorNumber).FirstOrDefault() ?? 0;

                    if (errornumber == 0)
                    {
                        throw new Exception("Codigo de Error: " + errornumber + " Mensaje de Error: " +
                            respuestaImportacionCC.Select(a => a.ErrorMessage).FirstOrDefault());
                    }


                    //Tomamos el Numero de Clientes segun el key del App.config
                    oResultado = (from a in oConsultar.BizOnBaseClientesCorps
                                          select new eClientesCorpOnBase(
                                              a.No_Cliente,
                                              a.codigo
                                              )).ToList();
                }
            }
            catch (EntityException ex)
            {
                throw ex;
            }
            return oResultado;
        }


        /// <summary>
        /// Metodo para traer valor de Dias Documentos Pendientes para Creditos para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        public int ConsultaPeriodoProdCredito()
        {
            int datoProductoCredito;
            //Trayendo valor para productos Vencidos parametrica en ReportesBizagi
            using (ReportesBizagiEntities oConsultaBizagi = new ReportesBizagiEntities())
            {
                datoProductoCredito = (from a in oConsultaBizagi.V_BizValidacionDocPendientes
                                       where a.descripcion == "ValidacionDiasCredito"
                                       select a.constante).FirstOrDefault() ?? 0;
            }
            return datoProductoCredito;
        }

        /// <summary>
        /// Metodo para traer valor de Dias Documentos Pendientes para Tarjetas para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        public int ConsultaPeriodoProdTarjeta()
        {
            int datoProductoTarjeta;
            //Trayendo valor para productos Vencidos parametrica en ReportesBizagi
            using (ReportesBizagiEntities oConsultaBizagi = new ReportesBizagiEntities())
            {
                datoProductoTarjeta = (from a in oConsultaBizagi.V_BizValidacionDocPendientes
                                       where a.descripcion == "ValidacionDiasTC"
                                       select a.constante).FirstOrDefault() ?? 0;
            }
            return datoProductoTarjeta;
        }

        /// <summary>
        /// Metodo para traer valor de vencimiento para generar alerta al crear Casos Bizagi
        /// </summary>
        /// <returns></returns>
        public int ConsultaPeriodoVencimiento()
        {
            int datoVencimiento;
            //Trayendo valor para productos Vencidos parametrica en ReportesBizagi
            using (ReportesBizagiEntities oConsultaBizagi = new ReportesBizagiEntities())
            {
                datoVencimiento = (from a in oConsultaBizagi.V_BizValidacionDocVencidos
                                   select a.constante).FirstOrDefault() ?? 0;
            }
            return datoVencimiento;
        }

        /// <summary>
        /// Ejecuta de manera Asincrona la tarea que corre el metodo que ejecuta un Parallel LINQ
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public async Task<IList<eControlDocument>> ObtenerDocPendientesAsync(long clientId)
        {
            return await Task.Run(() => ObtenerDocPendientes(clientId)).ConfigureAwait(false);
        }

        /// <summary>
        /// Ejecuta de manera Asincrona la tarea que corre el metodo que ejecuta un Parallel LINQ
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="vencimientoProductos"></param>
        /// <returns></returns>
        public async Task<IList<eControlDocument>> ObtenerDocVencidossAsync(long clientId, int vencimientoProductos)
        {
            return await Task.Run(() => ObtenerDocVencidos(clientId, vencimientoProductos)).ConfigureAwait(false);
        }

        /// <summary>
        /// Ejecuta de manera Asincrona el SP OBNIC_Doc_FaltantesxCliente que permite consultar los documentos Pendientes por cliente
        /// </summary>
        /// <param name="clientId"></param>
        /// <returns></returns>
        public IList<eControlDocument> ObtenerDocPendientes(long clientId)
        {
            IList<eControlDocument> docsPendientes;

            //Ejecutando SP
            using (onbaseEntities oConsultar = new onbaseEntities())
            {
                var listaRaw = oConsultar.Database.SqlQuery<eDocFaltantes>(string.Format("EXEC [hsi].[OBNIC_Doc_FaltantesxCliente] @NumCliente = {0}", clientId)).AsParallel();

                docsPendientes = listaRaw.Select(x => new eControlDocument()
                {
                    //Mapeo
                    NoCliente = x.NroCliente,
                    ClaseDocumento = x.ClaseDocumento,
                    TipoProducto = x.TipoProducto,
                    NoProducto = string.IsNullOrEmpty(x.NumProducto) ? (long?)null : Convert.ToInt64(x.NumProducto),
                    TipoDocumento = x.TipoDocumentoOB,
                    FechaVencimiento = null,
                    Clasificacion = 1
                }).ToList();
            }
            return docsPendientes;
        }

        /// <summary>
        /// Ejecuta de manera Asincrona el SP OBNIC_Doc_VencidosxCliente que permite consultar los documentos Vencidos por cliente
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="vencimientoProductos"></param>
        /// <returns></returns>
        public IList<eControlDocument> ObtenerDocVencidos(long clientId, int vencimientoProductos)
        {
            IList<eControlDocument> docsVencidos = BasicObtenerDocVencidos(clientId, vencimientoProductos);

            if (docsVencidos.Any())
            {
                //Aumentamos 30 dias (1 mes) a los meses por Defecto
                vencimientoProductos = vencimientoProductos + Convert.ToInt32(ConfigurationManager.AppSettings["ValorSegundaRonda"]);
                docsVencidos = BasicObtenerDocVencidos(clientId, vencimientoProductos);
            }

            return docsVencidos;
        }

        /// <summary>
        /// Metodo para traer los Documentos Vencidos por Cliente, se separo la logica para poder ejecutarlo
        /// dos veces, en caso de contar con Documentos a los 3 meses, se ejecuta con 4 meses
        /// </summary>
        /// <param name="clientId"></param>
        /// <param name="vencimientoProductos"></param>
        /// <returns></returns>
        public IList<eControlDocument> BasicObtenerDocVencidos(long clientId, int vencimientoProductos)
        {
            IList<eControlDocument> docsVencidos = new List<eControlDocument>();

            //Ejecutando SP
            using (onbaseEntities oConsultar = new onbaseEntities())
            {
                foreach (var item in oConsultar.OBNIC_Doc_VencidosxCliente(Convert.ToDecimal(clientId), Convert.ToDecimal(vencimientoProductos)).AsParallel())
                {
                    //Ingresa cada Elemento en el IList a retornar
                    docsVencidos.Add(new eControlDocument(
                        (int)(item.NroCliente ?? 0),
                         item.ClaseDocumento,
                         item.TipoProducto,
                         Convert.ToInt64(item.NumProducto),
                         item.TipoDocumentoOB,
                         item.FechaVencimiento,
                         2
                        ));
                }
            }
            return docsVencidos;
        }

        /// <summary>
        /// Metodo para insertar data en la tabla de Consolidado que contiene todos los documentos Pendientes y Vencidos
        /// </summary>
        /// <param name="listaPorInsertar"></param>
        public void InsertarDatosConsolidado(IList<eControlDocument> listaPorInsertar)
        {
            //Contexto generado por Entity Framework
            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                //Usamos un transaction scope para Commitear el BulkInsert, sin esto no se realiza
                using (var transactionScope = new TransactionScope())
                {
                    List<BizConsolidadoControlDoc> listaInsertar = listaPorInsertar.Select(item => new BizConsolidadoControlDoc
                    {
                        NumeroDeCliente = item.NoCliente,
                        ClaseDeDocumento = item.ClaseDocumento,
                        TipoDeProducto = item.TipoProducto,
                        NumeroDeProducto = item.NoProducto,
                        TipoDeDocumento = item.TipoDocumento,
                        FechaDeVencimiento = item.FechaVencimiento,
                        Clasificacion = item.Clasificacion,
                        FlagProcesado = false
                    }).ToList();

                    //Convertimos la clase Entidad eControlDocument a una clase de tipo Entity Framework, la magia del Bulk Insert esta aca al final...
                    oConsultar.BulkInsert(listaInsertar);
                    oConsultar.SaveChanges();

                    transactionScope.Complete();
                    transactionScope.Dispose();
                }
            }
        }

        /// <summary>
        /// Metodo para truncar la tabla de Consolidado que contiene todos los documentos Pendientes y Vencidos
        /// </summary>
        public void TruncarTablaConsolidado()
        {
            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                oConsultar.Database.ExecuteSqlCommand("TRUNCATE TABLE [dbo].[BizConsolidadoControlDocs];");
            }
        }
    }
}

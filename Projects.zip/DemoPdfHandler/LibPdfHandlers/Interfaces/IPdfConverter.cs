﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LibPdfHandlers.Interfaces
{
    public interface IPdfConverter
    {
        /// <summary>
        /// Metodo para convertir archivo PDF a byte[]
        /// </summary>
        /// <param name="pdfPathFile"></param>
        /// <returns></returns>
        byte[] PdfToBytes(string pdfPathFile);

        /// <summary>
        /// Metodo para convertir arreglo byte[] a PDF
        /// </summary>
        /// <param name="pdfExportPathFile">Ruta que contiene el archivo a generar como PDF</param>
        /// <param name="bytes">Arreglo de Bytes tomado de base de datos para convertir a pdf el archivo.</param>
        string BytesToPdf(string pdfExportPathFile, byte[] bytes);
    }
}

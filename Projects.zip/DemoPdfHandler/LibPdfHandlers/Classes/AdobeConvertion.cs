﻿using System;
using System.Collections.Generic;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace LibPdfHandlers.Classes
{
    public class AdobeConvertion : IDisposable
    {
        public int PageCount = 0;
        Acrobat.CAcroPDDoc pdfDoc = new Acrobat.AcroPDDoc();
        Acrobat.CAcroPDPage pdfPage = null;
        Acrobat.CAcroRect pdfRect = new Acrobat.AcroRect();
        Acrobat.AcroPoint pdfPoint = new Acrobat.AcroPoint();

        #region Convert
        /// <summary>
        /// Convierte Archivos PDF a Formato de Imagenes especificados
        /// </summary>
        /// <param name="sourceFileName">Ruta y Archivo PDF Fuente</param>
        /// <param name="destinationPath">Ruta y Archivo PDF Destino</param>
        /// <param name="outPutImageFormat">Tipo de Imagen a Exportar</param>
        /// <returns>Retorna el conteo de Imagenes Exportadas</returns>
        public int Convert(string sourceFileName, string destinationPath, ImageFormat outPutImageFormat)
        {
            if (pdfDoc.Open(sourceFileName))
            {
                PageCount = pdfDoc.GetNumPages();

                for (int i = 0; i < PageCount; i++)
                {
                    pdfPage = (Acrobat.CAcroPDPage)pdfDoc.AcquirePage(i);
                    
                    pdfPoint = (Acrobat.AcroPoint)pdfPage.GetSize();
                    pdfRect.Left = 0;
                    pdfRect.right = pdfPoint.x;
                    pdfRect.Top = 0;
                    pdfRect.bottom = pdfPoint.y;

                    pdfPage.CopyToClipboard(pdfRect, 0, 0, 100);

                    string outimg = "";
                    string filename = sourceFileName.Substring(sourceFileName.LastIndexOf("\\"));
                    
                    if (PageCount == 1)
                    {
                        outimg = destinationPath + filename + "." + outPutImageFormat.ToString();
                    }
                    else
                    {
                        outimg = destinationPath + filename + "_" + i.ToString() + "." + outPutImageFormat.ToString();
                    }
                    
                    Clipboard.GetImage().Save(outimg, outPutImageFormat);    
                }

                Dispose();
            }
            else
            {
                Dispose();
                throw new System.IO.FileNotFoundException(sourceFileName + " No encontrado!");
            }
            return PageCount;
            //Utilizar sentencia yield ... cuando se vaya a retornar un tipo IEnumerator<byte[]>
        }
        #endregion

        #region Conversion con Zoom
        /// <summary>
        /// Convierte Archivos PDF a Formato de Imagenes especificados utilizando Zoom
        /// </summary>
        /// <param name="sourceFileName">Ruta y Archivo PDF Fuente</param>
        /// <param name="destinationPath">Ruta y Archivo PDF Destino</param>
        /// <param name="outPutImageFormat">Tipo de Imagen a Exportar</param>
        /// <param name="width">Ancho de la imagen a exportar</param>
        /// <param name="height">Altura de la imagen a exportar</param>
        /// <param name="zoom">Porcentaje de Zoom</param>
        /// <returns>Retorna el conteo de Imagenes Exportadas</returns>
        public int Convert(string sourceFileName, string destinationPath, ImageFormat outPutImageFormat, short width, short height, short zoom)
        {
            if (pdfDoc.Open(sourceFileName))
            {
                PageCount = pdfDoc.GetNumPages();

                for (int i = 0; i < PageCount; i++)
                {
                    pdfPage = (Acrobat.CAcroPDPage)pdfDoc.AcquirePage(i);

                    pdfRect.Left = 0;
                    pdfRect.right = width; //pdfPoint.x;
                    pdfRect.Top = 0;
                    pdfRect.bottom = height; //pdfPoint.y;

                    pdfPage.CopyToClipboard(pdfRect, 0, 0, zoom);

                    string outimg = "";
                    string filename = sourceFileName.Substring(sourceFileName.LastIndexOf("\\"));

                    if (PageCount == 1)
                        outimg = destinationPath + "\\" + filename + "." + outPutImageFormat.ToString();
                    else
                        outimg = destinationPath + "\\" + filename + "_" + i.ToString() + "." + outPutImageFormat.ToString();

                    Clipboard.GetImage().Save(outimg, outPutImageFormat);
                }
                Dispose();
            }
            else
            {
                Dispose();
                throw new System.IO.IOException("Archivo especificado no ha sido encontrado!");
            }
            return PageCount;
        }

        #endregion
        
        #region Destructor

        /** DESTRUCTOR para realizar liberacion explicita de recursos, ante Interrupción 
         *  de Ejecución Abrupta del programa. Se llena la bandeja de Background Process
         *  con instancias de Adobe Acrobat 9.0, sí ante cierres Abruptos no se usa el DESTRUCTOR
         */

        ~AdobeConvertion()
        {
            GC.Collect();
            if (pdfPage != null)
            {
                Marshal.ReleaseComObject(pdfPage);
                Marshal.ReleaseComObject(pdfPoint);
                Marshal.ReleaseComObject(pdfRect);
                Marshal.ReleaseComObject(pdfDoc);
            }
        }
        public void Dispose()
        {
            GC.Collect();
            if (pdfPage != null)
            {
                Marshal.ReleaseComObject(pdfPage);
                Marshal.ReleaseComObject(pdfPoint);
                Marshal.ReleaseComObject(pdfRect);
                Marshal.ReleaseComObject(pdfDoc);
            }
        }

        #endregion
    }
}

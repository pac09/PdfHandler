﻿using System.IO;
using System.Text;

namespace LibPdfHandlers.Classes
{
    public class PdfConverter
    {
        /// <summary>
        /// Metodo para convertir archivo PDF a byte[]
        /// </summary>
        /// <param name="pdfPathFile"></param>
        /// <returns></returns>
        public byte[] PdfToBytes(string pdfPathFile)
        {
            byte[] bytes;

            string pathFile = pdfPathFile + "test.pdf";
            using (var stream = new FileStream(pathFile, FileMode.Open, FileAccess.Read))
            {
                using (var reader = new BinaryReader(stream)) 
                {
                    bytes = reader.ReadBytes((int) stream.Length);
                }
            }          
            return bytes;
        }

        /// <summary>
        /// Metodo para convertir arreglo byte[] a PDF
        /// </summary>
        /// <param name="pdfExportPathFile">Ruta que contiene el archivo a generar como PDF</param>
        /// <param name="bytes">Arreglo de Bytes tomado de base de datos para convertir a pdf el archivo.</param>
        public string BytesToPdf(string pdfExportPathFile, byte[] bytes)
        {
            string fileName = "myfile.pdf";
            System.IO.File.WriteAllBytes(pdfExportPathFile + fileName, bytes);
            
            return fileName;
        }
        
    }

}

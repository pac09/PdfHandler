﻿using System;
using System.Collections.Generic;
using System.IO;

namespace LibPdfHandlers.Classes
{
    public class SautinConvertion 
    {
        /// <summary>
        /// Metodo para convertir PDF en byte[] en una List<byte[]> que contenga las paginas (como archivos jpg)
        /// </summary>
        /// <param name="pdfBytes"></param>
        /// <returns></returns>
        public List<byte[]> PdfConvertion(byte[] pdfBytes)
        {
            List<byte[]> paginasPorArchivo  = new List<byte[]>();
            SautinSoft.PdfFocus f = new SautinSoft.PdfFocus();
            SautinSoft.PdfVision v = new SautinSoft.PdfVision();
            
            f.Serial = "";
            f.OpenPdf(pdfBytes);

            if (f.PageCount > 0)
            {
                for (int page = 1; page <= f.PageCount; page++)
                {
                    //Armando ruta donde se creara el archivo (Esto para ejemplo, ya que lo ideal es guardar el binario en BD)
                    string jpegPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Personal).ToString(),
                        String.Format(String.Format("{0:yyyy/MM/dd}_{0:HH:mm:ss tt}", DateTime.Now)
                                          .Replace("/", "-")
                                          .Replace(":", "-")
                                          .Replace(" ", "-") + "_page{0}.jpg", page));

                    //Salvando Imagen en archivo fisico  JPG (Solo se usa PdfFocus)
                    f.ToImage(jpegPath, page);
                    jpegPath = jpegPath.Replace("jpg", "pdf");
                    


                    //salvando Imagen en Binario en variable "Pagina", con esto despues lo podrian pasar a b64 o almacenarlo directamente en BD.
                    var pagina = f.ToImage(page);
                    paginasPorArchivo.Add(pagina);
                }
            }
            f.ClosePdf();

            return paginasPorArchivo;
        }

        

    }
}

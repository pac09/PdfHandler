﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Data.Model;

namespace Data.Interfaces
{
    public interface IDataOperations
    {
        /// <summary>
        /// Metodo para insertar archivo PDF en tabla de control
        /// </summary>
        /// <param name="registroPendienteDerocesar"></param>
        void InsertaPdfPorProcesar(TarjetaDeFirma registroPendienteDerocesar);

        /// <summary>
        /// Metodo para traer el ultimo PDF importado a Base de datos el cual no esta Procesado
        /// </summary>
        /// <returns></returns>
        TarjetaDeFirma ObtenerRegistroMasReciente();
    }
}

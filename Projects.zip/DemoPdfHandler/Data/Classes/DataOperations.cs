﻿using System.Linq;
using System.Runtime.Remoting.Messaging;
using Data.Interfaces;
using Data.Model;
using Data.ReportesBizagi;

namespace Data.Classes
{
    public class DataOperations : IDataOperations
    {
        /// <summary>
        /// Metodo para insertar archivo PDF en tabla de control
        /// </summary>
        /// <param name="registroPendienteDerocesar"></param>
        public void InsertaPdfPorProcesar(TarjetaDeFirma registroPendienteDerocesar)
        {
            ReportesBizagiEntities oInsertar = new ReportesBizagiEntities();

            var dataPorInsertar = new CMN_TarjetasDeFirmas()
            {
                NoCaso = registroPendienteDerocesar.NoCaso,
                Archivo = registroPendienteDerocesar.Archivo,
                Procesado = registroPendienteDerocesar.Procesado
            };

            oInsertar.CMN_TarjetasDeFirmas.Add(dataPorInsertar);
            oInsertar.SaveChanges();
        }


        /// <summary>
        /// Metodo para traer el ultimo PDF importado a Base de datos el cual no esta Procesado
        /// </summary>
        /// <returns></returns>
        public TarjetaDeFirma ObtenerRegistroMasReciente()
        {
            TarjetaDeFirma ultimoPdf;

            using (ReportesBizagiEntities oConsultar = new ReportesBizagiEntities())
            {
                ultimoPdf = oConsultar.CMN_TarjetasDeFirmas.Where(a => a.Procesado == false).Select(b => new TarjetaDeFirma()
                {
                    NoCaso = b.NoCaso,
                    Archivo = b.Archivo,
                    Procesado = b.Procesado  
                }).FirstOrDefault();
            }

            return ultimoPdf;
        }
    }

}

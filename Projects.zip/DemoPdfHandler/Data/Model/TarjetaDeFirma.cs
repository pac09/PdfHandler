﻿using System;

namespace Data.Model
{
    public class TarjetaDeFirma
    {
        public string NoCaso { get; set; }
        public byte[] Archivo { get; set; }
        public bool Procesado { get; set; }
    }
}

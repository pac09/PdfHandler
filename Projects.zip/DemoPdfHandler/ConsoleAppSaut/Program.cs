﻿using System;
using System.Threading;
using ConsoleAppSaut.Extensiones;
using ConsoleAppSaut.ImplementationMethods;

namespace ConsoleAppSaut
{
    public class Program
    {
        static readonly Menu ObjMenu = new Menu();
        static readonly OperacionesPorArchivos ImporExporArchivos = new OperacionesPorArchivos();
        static readonly SautinMethod MetodoSautin = new SautinMethod();
        static readonly AdobeMethod MetodoAdobe = new AdobeMethod();

        [STAThread()]
        static void Main(string[] args)
        {
            #region ImportarArchivo

            Console.Write("Se inicia lectura de archivo pdf en la ruta de Origen para importarlo a Base de Datos\r\n");
            ImporExporArchivos.EjecutarImportacion();
            Console.Write("Ha finalizado la lectura de archivo pdf y fue salvado en base de datos\r\n\r\n");

            #endregion

            var valorMenu = ObjMenu.MostrarMenu();

            switch (valorMenu)
            {
                case 1:
                    Console.Write("Se inicia el Metodo de la DLL de SautinSoft");

                    //Barra de progreso
                    using (var progressObtenerClientes = new ProgressBar())
                    {
                        //Traemos el Cliente mas Reciente
                        var registroReciente = ImporExporArchivos.ObtenerRegistroMasReciente();
                        //Hacemos la conversion usando DLL de SautinSoft
                        var pdfInJpgSeparado = MetodoSautin.PdfConvertionMethod(registroReciente.Archivo);

                        for (int i = 0; i <= 100; i++)
                        {
                            progressObtenerClientes.Report((double)i / 100);
                            Thread.Sleep(50);
                        }
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("[##################################################]");
                    
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write(" Ejecutado.\r\n");
                    Console.ResetColor();

                    break;
                
                case 2:
                    Console.Write("Se inicia el Metodo de la DLL de Adobe");
                    int numeroDePaginas = 0;
                    //Exportamos a PDF el byte[] PDF en base de datos, abriremos dicho archivo para separar las paginas y convertirlas a JPG
                    var archivoGenerado = ImporExporArchivos.EjecutarExportacion();
                    
                    //Hacemos la conversion usando DLL de Acrobat
                    numeroDePaginas = MetodoAdobe.AdobePdfConvertionMethod(archivoGenerado);

                    //Barra de progreso
                    using (var progressObtenerClientes = new ProgressBar())
                    {
                        for (int i = 0; i <= 100; i++)
                        {
                            progressObtenerClientes.Report((double)i / 100);
                            Thread.Sleep(50);
                        }
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("[##################################################]");

                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.Write(" Ejecutado. No de paginas: " + Convert.ToString(numeroDePaginas) + "\r\n");
                    Console.ResetColor();

                    break;

                default:
                    Environment.Exit(0);
                    break;
            }

            Console.WriteLine("Presiona cualquier tecla para salir...");
            Console.ReadKey();
            
        }


       



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppSaut.Extensiones
{
    public class Menu
    {
        /// <summary>
        /// Metodo para reflejar menu en Consola
        /// </summary>
        /// <returns></returns>
        public int MostrarMenu()
        {
            Console.WriteLine("Escoger una de las siguientes Opciones:");
            Console.WriteLine();
            Console.WriteLine("1- Generar JPG por paginas utilizando SautinSoft");
            Console.WriteLine("2- Generar JPG usando DLLs de Adobe Acrobat;");
            Console.WriteLine("3- Salir del programa\r\n");
            var result = Console.ReadLine();
            return Convert.ToInt32(result);
        }
    }
}

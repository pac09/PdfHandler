﻿using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppSaut.Extensiones
{
    public class ProgressBar : IDisposable, IProgress<double>
    {
        private const int blockCount = 50;
        private readonly TimeSpan animationInterval = TimeSpan.FromSeconds(1.0 / 8);
        private const string animation = @"|/-\";

        private readonly Timer timer;

        private double currentProgress = 0;
        private string currentText = string.Empty;
        private bool disposed = false;
        private int animationIndex = 0;

        public ProgressBar()
        {
            timer = new Timer(TimerHandler);

            // Progress bar para ser mostrada temporalmente en console windows.
            // Si la salida de consola  es redirigida a un archivo, no se dibuja nada
            // De cualquier otro modo, terminará con un monton de caracteres ilegibles en el archivo.
            if (!Console.IsOutputRedirected)
            {
                ResetTimer();
            }
        }

        public void Report(double value)
        {
            // Asegurase que el valor este en el rango [0..1]
            value = Math.Max(0, Math.Min(1, value));
            Interlocked.Exchange(ref currentProgress, value);
        }

        private void TimerHandler(object state)
        {
            lock (timer)
            {
                if (disposed) return;

                int progressBlockCount = (int)(currentProgress * blockCount);
                int percent = (int)(currentProgress * 100);
                string text = string.Format("[{0}{1}] {2,3}% {3}",
                    new string('#', progressBlockCount), new string('-', blockCount - progressBlockCount),
                    percent,
                    animation[animationIndex++ % animation.Length]);
                ActualizaTexto(text);

                ResetTimer();
            }
        }

        private void ActualizaTexto(string text)
        {
            // Obtiene longitud de la porcion comun
            int commonPrefixLength = 0;
            int commonLength = Math.Min(currentText.Length, text.Length);
            while (commonPrefixLength < commonLength && text[commonPrefixLength] == currentText[commonPrefixLength])
            {
                commonPrefixLength++;
            }

            // Sigue pista del primer caracter diferente
            StringBuilder outputBuilder = new StringBuilder();
            outputBuilder.Append('\b', currentText.Length - commonPrefixLength);

            // Da salida a nuevo sufijo
            outputBuilder.Append(text.Substring(commonPrefixLength));

            // Si el nuevo texto es mas corto que el viejo: borrar caracteres que hacen overlapping
            int overlapCount = currentText.Length - text.Length;
            if (overlapCount > 0)
            {
                outputBuilder.Append(' ', overlapCount);
                outputBuilder.Append('\b', overlapCount);
            }

            Console.Write(outputBuilder);
            currentText = text;
        }

        private void ResetTimer()
        {
            timer.Change(animationInterval, TimeSpan.FromMilliseconds(-1));
        }

        public void Dispose()
        {
            lock (timer)
            {
                disposed = true;
                ActualizaTexto(string.Empty);
            }
        }
    }
}

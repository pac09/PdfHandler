﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing.Imaging;
using System.Net;
using LibPdfHandlers.Classes;

namespace ConsoleAppSaut.ImplementationMethods
{
    public delegate int AdobePdfConvertionDelegate(string sourceFileName, string destinationPath, ImageFormat outPutImageFormat);

    public class AdobeMethod
    {
        public static AdobeConvertion Convertion;
        public static AdobePdfConvertionDelegate PdfConvertionDelegate = null;

        /// <summary>
        /// Constructor para inicializar Delegado y abstraer logica
        /// </summary>
        public AdobeMethod()
        {
            Convertion = new AdobeConvertion();
            PdfConvertionDelegate = new AdobePdfConvertionDelegate(Convertion.Convert);
        }

        public int AdobePdfConvertionMethod(string paramSourceFileName)
        {
            //Tomamos de App.config la ruta de Directorio para colocar archivos generados
            string rutaExportarImagenes = ConfigurationManager.AppSettings["ExportDirectoryImg"].ToString();
            //Tomamos de App.config la extension de imagen a generar
            string tipoDeImagen = ConfigurationManager.AppSettings["ImageExtention"].ToString();

            ImageFormat imageFormat = new ImageFormat(Guid.Empty);
            switch (tipoDeImagen)
            {
                case "Jpeg":
                    imageFormat = ImageFormat.Jpeg;
                    break;

                case "Bmp":
                    imageFormat = ImageFormat.Bmp;
                    break;

                case "Png":
                    imageFormat = ImageFormat.Png;
                    break;

                case "Gif":
                    imageFormat = ImageFormat.Gif;
                    break;
            }

            return PdfConvertionDelegate(paramSourceFileName, rutaExportarImagenes, imageFormat);
        }

    }
}
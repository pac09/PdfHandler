﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibPdfHandlers.Classes;

namespace ConsoleAppSaut.ImplementationMethods
{
    public delegate List<byte[]> PdfConvertionDelegate(byte[] pdfBytes);
    
    public class SautinMethod
    {
        public static SautinConvertion Convertion;
        public static PdfConvertionDelegate PdfConvertionDelegate = null;
        
        /// <summary>
        /// Constructor para inicializar Delegado y abstraer logica
        /// </summary>
        public SautinMethod()
        {
            Convertion = new SautinConvertion();
            PdfConvertionDelegate = new PdfConvertionDelegate(Convertion.PdfConvertion);
        }

        /// <summary>
        /// Metodo para implementacion de la logica según DLL de SautinSoft
        /// </summary>
        /// <param name="param"></param>
        /// <returns></returns>
        public List<byte[]> PdfConvertionMethod(byte[] param)
        {
            return PdfConvertionDelegate(param);
        }   
    }

}

﻿using System;
using System.Configuration;
using System.IO;
using Data;
using Data.Classes;
using Data.Interfaces;
using Data.Model;
using LibPdfHandlers.Classes;
using LibPdfHandlers.Interfaces;

namespace ConsoleAppSaut.ImplementationMethods
{
    public class OperacionesPorArchivos : IDataOperations, IPdfConverter
    {
        protected DataOperations DataOp;
        protected PdfConverter Converter;

        public OperacionesPorArchivos()
        {
            DataOp = new DataOperations();
            Converter = new PdfConverter();
        }

        #region MetodosPropios

        /// <summary>
        /// Metodo para ingresar en base de datos el archivo PDF y simular que es una tabla de Bizagi, que almaceno el PDF como VARBINARY
        /// </summary>
        public void EjecutarImportacion()
        {
            string archivoPdf = ConfigurationManager.AppSettings["ImportDirectory"].ToString();

            //Creando Objeto a guardar en base de datos
            TarjetaDeFirma objetoPorGuardar = new TarjetaDeFirma()
            {
                NoCaso = "CMN00001",
                Archivo = PdfToBytes(archivoPdf),
                Procesado = false
            };

            DataOp.InsertaPdfPorProcesar(objetoPorGuardar);
        }
        


        public string EjecutarExportacion()
        {
            var clienteMasReciente = ObtenerRegistroMasReciente();
            
            //Ruta para exportar archivo
            string pathFile = ConfigurationManager.AppSettings["ExportDirectoryPdf"].ToString();
            //Generando archivo en ruta especificada
            string fileName = BytesToPdf(pathFile, clienteMasReciente.Archivo);

            return string.Concat(pathFile, fileName);
        }


        #endregion
        
        #region Implementacion_ImporExporPDF

        public void InsertaPdfPorProcesar(TarjetaDeFirma registroPendienteDerocesar)
        {
            DataOp.InsertaPdfPorProcesar(registroPendienteDerocesar);
        }

        public TarjetaDeFirma ObtenerRegistroMasReciente()
        {
            return DataOp.ObtenerRegistroMasReciente();
        }

        #endregion
        
        #region Converter

        public byte[] PdfToBytes(string pdfPathFile)
        {
            return Converter.PdfToBytes(pdfPathFile);
        }

        public string BytesToPdf(string pdfExportPathFile, byte[] bytes)
        {
            return Converter.BytesToPdf(pdfExportPathFile, bytes);
        }

        //Hace falta metodo para eliminar PDF generado en carpeta de Exportacion
        #endregion
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CENAOClient.ActionResults;

namespace CENAOClient.Controllers
{
    public class BaseController : Controller
    {
        // GET: Base
        public BetterJsonResult<T> BetterJson<T>(T model)
        {
            return new BetterJsonResult<T>() { Data = model };
        }
    }
}
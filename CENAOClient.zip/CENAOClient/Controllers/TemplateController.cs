﻿using System.Web.Mvc;

namespace CENAOClient.Controllers
{
    public class TemplateController : BaseController
    {
        public PartialViewResult Render(string feature, string name)
        {
            return PartialView($"~/js/app/{feature}/templates/{name}");
        }
    }
}